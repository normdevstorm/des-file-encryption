import{a as r}from"./actionSettings.D_CkdFjL.js";var t=r,a=function(){try{var e=t(Object,"defineProperty");return e({},"",{}),e}catch{}}(),v=a;export{v as _};
