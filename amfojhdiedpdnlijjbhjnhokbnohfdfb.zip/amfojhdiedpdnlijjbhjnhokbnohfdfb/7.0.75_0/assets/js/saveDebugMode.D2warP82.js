const t="ejoyDebugMode";async function o(){try{return(await chrome.storage.local.get(t))[t]||!1}catch{}return!1}function r(e){chrome.storage.local.set({[t]:e})}export{o as g,t as k,r as s};
