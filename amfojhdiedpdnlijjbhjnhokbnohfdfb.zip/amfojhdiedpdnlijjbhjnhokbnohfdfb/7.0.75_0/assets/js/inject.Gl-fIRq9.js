import{R as se,v as ie,a as ne,r as re}from"./react-shadow-dom-retarget-events.i_HYNrBb.js";import{l as H,a as ae,j as J,r as le}from"./index.DQ5C7vZ5.js";import{d as X,r as V,c as j,s as R,l as ce,m as de,n as ue,j as he}from"./index.q0C_7fnv.js";import{a as pe,c as N,b as me,d as fe}from"./index.D_CL30xq.js";import{d as f,f as d,g as Y,b as E,c as P,_ as $}from"./actionSettings.D_CkdFjL.js";import{w as ge,a as ye}from"./settingOnOff.DcRsjbt_.js";import{S as be}from"./sweetalert2.all.Bh7O6qfp.js";import{_ as we}from"./index.BtaSwFLH.js";import{f as Se,t as xe}from"./helper.5qE4Nvhb.js";import{p as ve,a as Ce,_ as Te,g as ke,e as Ee,s as Pe,c as Me}from"./popup.CxvBecjP.js";import{a as qe}from"./unionBy.4oU2Onzr.js";import{s as _e}from"./index.Dki2r1X_.js";import{g as Le,a as Re}from"./subtitleLookup.C_La7k10.js";import{c as Oe}from"./index.CJKliNYn.js";import{f as Be}from"./index.D273vk8G.js";function Ae(r){try{const e=r.data.type,t=document.querySelector("video");if(t)switch(e){case"seek":const s=r.data.second;t.currentTime=s;break;case"play":t.play();break;case"pause":t.pause();break;case"getTime":break;default:break}}catch{}}function De(r){try{const e=r.data.type,t=document.querySelector("video");(e==="seek"||e==="play"||e==="pause")&&document.querySelector("iframe").contentWindow.postMessage(r.data,"*")}catch{}}function He(){window.location.pathname&&window.location.host==="www.youtube.com"&&window.location.pathname.indexOf("/embed/")>=0&&window.location.href.indexOf("autoplay=1&controls=0&v=3")>=0&&window.addEventListener("message",Ae);const r=f.get("embedYoutubeFromWebHost"),e=f.get("embedYoutubeFromWebCheck");window.location.pathname&&window.location.host===r&&window.location.pathname.indexOf(e)>=0&&window.addEventListener("message",De)}const mt=()=>{try{document.querySelector("iframe#iframePlayVideoYt").contentWindow.postMessage({type:"play",second:100},"*")}catch{}},ft=()=>{try{document.querySelector("iframe#iframePlayVideoYt").contentWindow.postMessage({type:"pause",second:100},"*")}catch{}},gt=r=>{try{document.querySelector("iframe#iframePlayVideoYt").contentWindow.postMessage({type:"seek",second:r},"*")}catch{}};function z(r){let e=0,t=0,s=0,o=0;const i=`#${r.id}header`;r.querySelector(i)?r.querySelector(i).onmousedown=n:r.onmousedown=n;function n(c){c=c||window.event,c.preventDefault(),s=c.clientX,o=c.clientY,r.onmouseup=l,document.onmousemove=a}function a(c){c=c||window.event,c.preventDefault(),e=s-c.clientX,t=o-c.clientY,s=c.clientX,o=c.clientY,r.style.top=r.offsetTop-t+"px",r.style.left=r.offsetLeft-e+"px"}function l(){r.onmouseup=null,r.onmousemove=null,document.onmousemove=null}}const I=(r,e)=>{r&&(r.onmouseup=null,r.onmousemove=null,document.onmousemove=null)},x=X.KEY_BOARD,M=j.fontTypeSubtitle,W=j.initialStyleSubtitle,q="ejoy-sub-clzz",S="ejoy-sub-hovered",O="glot-subtitles__sub__con",B={fixedDom:"fixedDom",videoTrack:"videoTrack"},F=X.eJOYPopId,_={},A={};let k="",D=null;const C="ej-main-sub",L="ej-trans-sub";class $e{constructor(){this.handleChangeHref=()=>{let e=document.location.href;const t=document.querySelector("body");new MutationObserver(o=>{e!==document.location.href&&(e=document.location.href,this.video=null,window.isMove=!1,window.isMainMove=!1)}).observe(t,{childList:!0,subtree:!0})},this.addCssHiddenSubWithVideoTrack=e=>{if(e)this.addCssHiddenSubWithVideoTrackShadown();else{const t=document.createElement("style");t.innerHTML="video::cue { font-size: 0px !important}",document.head.appendChild(t)}},this.addCssHiddenSubWithShawdowRoot=()=>{try{const e=this.splitByShadowRoot(this.idOrClassSub),t=e.length;if(t<=1)return null;let s=document.querySelector(e[0]).shadowRoot.querySelector(e[1]),o=document.querySelector(e[0]).shadowRoot,i=e[1];if(t>2)for(let n=2;n<t;n++)s&&(o=s.shadowRoot,s=s.shadowRoot.querySelector(e[n]),i=e[n]);if(o&&!o.querySelector("#styleHiddenSubEj")){const n=document.createElement("style");n.id="styleHiddenSubEj",n.innerHTML=`
          ${i} { transform: translateX(10000px); opacity: 0 !important; }
        `,o.appendChild(n)}}catch{}},this.parseClass=e=>{const t=e;try{const s=d((t||"").match(new RegExp("videoRootDom:(.*?[^\\\\])@","i"))||[],"[1]","").trim(),o=d((t||"").match(new RegExp("classSubDom:(.*?[^\\\\])@","i"))||[],"[1]","").trim(),i=d((t||"").match(new RegExp("parentDom:(.*?[^\\\\])@","i"))||[],"[1]","").trim(),n=d((t||"").match(new RegExp("typeVideo:(.*?[^\\\\])@","i"))||[],"[1]","").trim();let a=d((t||"").match(new RegExp("offsetY:(.*?[^\\\\])@","i"))||[],"[1]","").trim(),l=d((t||"").match(new RegExp("isBottom:(.*?[^\\\\])@","i"))||[],"[1]","").trim();return a=a?parseInt(a):0,{videoRootDom:s,isBottom:!!(l&&l==="true"),classSubDom:o,parentDom:i,typeVideo:n,offsetY:a}}catch{}return{offsetY:0}},this.handleChangeTextPriSub=(e,t,s,o="")=>{const i=this.getLangTo();let n=o;if(this.parentElementDom&&(n=document.querySelector(this.parentElementDom)),n||(this.isSubTrack?n=this.video?this.video.parentElement:t.parentElement:n=this.video?this.video.parentElement:t.parentElement),!n)return;this.renderIconFullScreen(n);const a=this.isForceBottom||this.isSubTrack||this.isShawdowRootPage;s&&this.renderShowAutoTranslate(e,i,t,n,a?180:this.offsetTransSub||30,a),(this.isReplaceSub||this.isSubTrack)&&!this.hiddenMainSub&&this.renderMainSub(e,t,n,a?100:10,a)},this.clearSub=()=>{const e=document.querySelector("."+L);e&&(e.innerText="");const t=document.querySelector("."+C);t&&(t.innerText="")},this.handleClickNewNeflix=()=>{document.querySelector("html#netflix .watch-video")&&(document.querySelector("html#netflix .watch-video").onclick=this.mouseClickHandler,this.isHandleClickNewNeflix=!0)},this.mouseClickHandler=e=>{document.querySelector(".ejoy-settings-wrapper")&&!document.querySelector(".ejoy-settings-wrapper").contains(e.target)&&window.dispatchEvent(new CustomEvent("closeSettingEjoy")),document.getElementById("ejoy")&&!document.getElementById("ejoy").contains(e.target)&&this.closePopup&&this.closePopup()},this.setLangTo=()=>{Y("lang",e=>{const t=d(e,"lang",{}),s=d(t,"translateTo.code","");document.body.setAttribute("data-lang-to",s)})},this.onMousedown=e=>{document.querySelector(`#${F}`)&&!document.querySelector(`#${F}`).contains(e.target)&&document.querySelector("[parent-subtitle]")&&!document.querySelector("[parent-subtitle]").contains(e.target)&&this.closePopup()},this.bodyClick=e=>{e.target.classList.contains(q)?this.clickTranslate(e,e.target.getAttribute("data-text"),""):e.target.classList.contains("view-icon-edit-sub")?this.goToSettingSub():e.target.classList.contains("view-icon-copy-main-sub")?this.copySub(this.subCache,"Copied main Subtitle !!!"):e.target.classList.contains("view-icon-copy-tran-sub")?this.copySub(this.subTranCache,"Copied trans Subtitle !!!"):e.target.classList.contains("view-icon-full-sub")||e.target.classList.contains("view-icon-exit-full-sub")?this.toggleFullSub():e.target.classList.contains("viewGoPro")&&this.goPopupProBlur()},this.splitByShadowRoot=e=>e?e.split("#shadowRoot#").filter(t=>t):[],this.getVideoElement=()=>{let e=null;if(this.isTrackShadowPage)try{e=document.querySelector("mux-player").shadowRoot.querySelector("mux-video").shadowRoot.querySelector("video")}catch{return null}else{const t=f.get("idOrClassVideoSource")||this.idOrClassVideoSource;if(e=document.querySelector(this.idOrClassVideo),this.idOrClassSub.indexOf("#shadowRoot#")>=0||this.videoRootElementDom&&this.videoRootElementDom.indexOf("#shadowRoot#")>=0){const s=this.splitByShadowRoot(this.videoRootElementDom?this.videoRootElementDom:this.idOrClassSub);e=this._getClassSubShadowRootVideo(s,!!this.videoRootElementDom)}else!e&&document.querySelector(t)&&(e=document.querySelector("video"))}return e},this.setVideo=()=>{try{this.video=this.getVideoElement()}catch{this.video=null}},this.pause=()=>{this.video||this.setVideo(),this.video&&ve(this.video)},this.play=()=>{this.closePopup&&this.closePopup(),this.playOrigin()},this.playOrigin=()=>{this.video&&Ce(this.video)},this.checkIsEnable=()=>this.idOrClassSub===O?document.documentElement.classList.contains("ejoy-enable"):!0,this.mouseOver=e=>{document.querySelector("[parent-subtitle]")&&document.querySelector("[parent-subtitle]").contains(e.target)?this.video&&!this.video.paused&&(this.pauseByHover=!0,this.pause()):!document.querySelector(`#${F}`)&&this.pauseByHover&&(e.target.getAttribute("parent-subtitle")||(this.pauseByHover=!1,this.playOrigin()))},this.fullscreenchange=()=>{window.isMove=!1,window.isMainMove=!1},this.showNotify=(e="saved")=>{be.fire({position:"top-end",icon:"success",title:e,toast:!0,showConfirmButton:!1,timer:2e3})},this.copySub=(e,t)=>{e&&chrome.runtime.sendMessage(E(P.copy_text,e),s=>{s.ok&&this.showNotify(t||"Copied !!!")})},this.toggleFullSub=()=>{const e=f.get("showFullSubCustom1")||{},t=this.domain?e[V(this.domain,"\\.","_")]:"";t&&(document.fullscreenElement?document.exitFullscreen():document.querySelector(t).requestFullscreen())},this.onKeyUp=(e,t=!1)=>{if(!t&&Oe(e)||!this.checkIsEnable())return;const{keyCode:s,altKey:o,shiftKey:i}=e;this.setVideo();try{switch(s){case x.KEY_C:{o&&this.copySub(this.subCache,"Copied main Subtitle !!!");break}case x.KEY_B:{o&&this.copySub(this.subTranCache,"Copied trans Subtitle !!!");break}case x.SPACE:this.closePopup&&this.closePopup();break;case x.ESCAPE:this._closePopup();break;case x.COMMA:case x.SUBTRACT:{if(i)return;this.indexHover--,this.isNext=!1,this.hoverByIndex(this.indexHover,o);break}case x.ADD:case x.PERIOD:{if(i)return;this.indexHover++,this.isNext=!0,this.hoverByIndex(this.indexHover,o);break}case x.KEY_J:o&&this.tranFullSub();break;default:break}}catch{}},this.mapStrToArr=e=>e?[...e].map(t=>({value:t,tag:!t||t===" "||t==="space"?"empty":"word"})):[],this.removeAllSelect=()=>{this.textSelected=[],document.querySelectorAll(`.${S}`).forEach(t=>{t.classList.remove(S)})},this.clickTranslate=async(e,t,s)=>{const o=e.altKey;let i=e.target,n=t;if(e&&o){if(!i.classList.contains(S))this.textSelected.push({text:n,target:e.target}),i.classList.add(S);else{Te(this.textSelected,c=>c.target===e.target),i.classList.remove(S);try{i=qe(this.textSelected).target}catch{}}n=this.textSelected.map(c=>c.text).join(" ")}else this.removeAllSelect(),e&&this.textSelected.push({text:n,target:e.target}),i.classList.add(S);const a=this.isNotParse&&document.querySelector(".ejoy-subtitles")?document.querySelector(".ejoy-subtitles").getAttribute("data-lang"):"",l=this.getLangTo();this.onClickShowPopup(n,s,i,a,l)},this.setClassToConPopup=()=>{const e="[class-container-popup]";return document.querySelector(e)?document.querySelector(e).getAttribute("class-container-popup"):(document.querySelector(this.containerPopup||"body").setAttribute("class-container-popup",e),e)},this.getClassToConPopupFull=()=>{const e="[class-container-popup-full-screen]";return document.querySelector(e)?document.querySelector(e).getAttribute("class-container-popup-full-screen"):(this.containerFullPopup?document.querySelector(this.containerFullPopup).setAttribute("class-container-popup-full-screen",e):this.video&&this.video.parentElement.setAttribute("class-container-popup-full-screen",e),e)},this.onClickShowPopup=(e,t,s,o,i)=>{const n=pe(s);this.showContentByText({text:e,rootClass:N()?this.getClassToConPopupFull():this.setClassToConPopup(),style:"",context:t,from:"auto",to:i,stylePopup:{position:"absolute",top:`${n.top}px`,left:`${n.left}px`,height:`${n.height}px`,maxHeight:`${n.height}px`,transform:`translateX(${n.translateX}%)`},posTriangle:""})},this.tranfull=(e,t)=>{const s=this.getLangTo();this.onClickShowPopup(e,e,t,"auto",s)},this.onMouseLeave=()=>{this.removeHoveredClass()},this.indexHover=-1,this.domData=null,this.textSelected=[],this.isPaused=!1,this.isSubTrack=!1,this.delayPlay=null,this.pauseByHover=!1,this.hiddenMainSub=!1,this.offsetTransSub=30,this.offsetY=0,this.isForceBottom=!1,this.ignorePro=!1,this.isShawdowRootPage=!1,this.isPro=!1,this.isHandleClickNewNeflix=!1,this.idOrClassSub="glot-subtitles__sub__con",this.domain="",this.containerPopup="",this.isReplaceSub=!1,this.containerFullPopup="",this.showContentByText=null,this.showIconSelect=null,this.optionsContext=null,this.options=null,this.style=null,this.video=null,this.parentElementDom=null,this.videoRootElementDom=null,this.isTrackShadowPage=!1,this.timeOutIconBlur=null,this.isNext=!0,this.enable=!1,this.isAutoTrans=!1,this.isShowCrownBlur=!1,this.closePopup=null,this.ignore=!1,this.isNextByWord=!1,this.customSearchWithRange=null,this.posEnable=!1,this.altKeyCache=!1,this.isNotParse=!1,this.isSpace=document.location.href.includes("wetv.vip")||document.location.href.includes("netflix.com"),this.subsTokenize=[],this.subCache="",this.subTranCache="",this.subHtml=[],this.subContentCache=[],this.fixedPos={left:0,top:0},this.styleLearning="",this.styleTrans="",this.colorMainSub="",this.colorTranSub="",this.idOrClassVideo='video[src]:not([src=""]):not(.tst-video-overlay-player-html5)',this.idOrClassVideoSource='video > source[src]:not([src=""]):not([src^="data:video"])'}checkChangeSub(e){D&&clearInterval(D),this.isSubTrack?D=window.setInterval(()=>{this.video||(this.setVideo(),window.isMove=!1,window.isMainMove=!1),this.getCurrentTrack(e)},500):D=window.setInterval(()=>{this.video||(this.setVideo(),window.isMove=!1,window.isMainMove=!1);const t=this.getClassSubElement();if(t){const o=t.length!==void 0&&t.length>0?this.getParentElement(t):t,i=(o.innerText||"").trim();!this.hiddenMainSub&&this.isReplaceSub&&this.hideOriginSub(o),this.isShawdowRootPage&&this.addCssHiddenSubWithShawdowRoot(),k!==i&&(k=i,i?(!this.isReplaceSub&&this.hoverByIndex(0,!1,!0),this.handleChangeTextPriSub(i,o,e)):this.clearSub())}else k&&(this.clearSub(),k="")},500)}actions(){try{const t=(f.get("actionsElement")||[]).find(s=>s.domain.indexOf(this.domain)>=0);if(t){const s=t.actions||[],o=t.delay||0;setTimeout(()=>{for(let i=0;i<s.length;i++){const n=s[i],a=document.querySelector(n.element);if(a)switch(n.type){case"remove":a.remove();break;default:break}}},o)}}catch{}}getCurrentTrack(e){if(!this.video)return;const t=f.get("kindSubTrack")||["subtitles","captions"],s=this.video.textTracks;for(const o in s){const i=s[o];if(i&&(t.includes(i.kind)||this.isTrackShadowPage)&&i.activeCues){const n=d(i,"activeCues.[0]");if(n&&k!==n.text){k=n.text;const a=this.video;let c=a.length!==void 0&&a.length>0?this.getParentElement(a):a,u=k;this.isTrackShadowPage?(u=u.startsWith("https")?"":u,c=document.querySelector("mux-player"),u&&this.handleChangeTextPriSub(u,c,e,this.isTrackShadowPage?c.parentElement:"")):this.handleChangeTextPriSub(u,c,e)}}}}async getProUser(){return new Promise(e=>{Y("user",t=>{const s=d(t,"user",{});e(Se(s,xe.dualSub))})})}addCssHiddenSubWithVideoTrackShadown(){setTimeout(()=>{try{const e=document.querySelector("mux-player").shadowRoot.querySelector("mux-video");if(e){const t=document.createElement("style");t.innerHTML="video::cue { font-size: 0px !important}",e.shadowRoot.appendChild(t)}}catch{this.addCssHiddenSubWithVideoTrackShadown()}},1e3)}prepare(e,t,s,o,i,n){this.showContentByText=e,this.customSearchWithRange=n,this.showIconSelect=s,this.optionsContext=o,window.isMove=!1,window.isMainMove=!1,Le(window.location.href).then(async a=>{const l=d(a,"domain",""),c=f.get("checkIgnoreProCase")||{},u=l?c[V(l,"\\.","_")]:"",v=f.get("videoShadowRoot")||["totaltypescript.com","courses.jsmastery.pro"];this.isTrackShadowPage=v.includes(l),this.ignorePro=!1,u&&(window.location.href.match(new RegExp(u),"g")?(this.hiddenMainSub=!0,this.offsetTransSub=50,this.ignorePro=!0):a={}),this.idOrClassSub=d(a,"elemClass","")||this.idOrClassSub,this.isPro=d(a,"isPro",!1)||this.isPro,this.enable=d(a,"enable",this.enable);const w=this.ignorePro||await this.getProUser();if(this.isPro&&(w||(this.enable=!1)),!w){const m=f.get("ignoreDomainPartlyBlurSub")||[];!(f.get("disableDomainPartlyBlurSub")||!1)&&l&&!m.includes(l)&&(this.timeOutIconBlur&&clearTimeout(this.timeOutIconBlur),this.timeOutIconBlur=setTimeout(()=>{this.isShowCrownBlur=!0},f.get("timeDelayShowIconProInVideoPartly")||6e4))}this.posEnable=d(a,"posEnable",!1)||this.posEnable,this.fixedPos=d(a,"pos","")||this.fixedPos,this.style=d(a,"style",W)||W,l==="linkedin.com"&&this.idOrClassSub.indexOf("###")<0&&(this.idOrClassSub="vjs-custom-captions-cue###vjs-text-track-display");const h=this.parseClass(this.idOrClassSub);if(this.parentElementDom=h.parentDom,this.isForceBottom=h.isBottom,this.videoRootElementDom=h.videoRootDom,this.offsetY=h.offsetY,this.idOrClassSub=h.classSubDom||this.idOrClassSub,!this.isTrackShadowPage&&h.typeVideo&&(this.isTrackShadowPage=h.typeVideo==="mux-player"),this.isShawdowRootPage=(this.idOrClassSub||"").indexOf("#shadowRoot#")>=0,we(this.style)>0){const m=d(this.style,"fontSizeMainSub",null),p=d(this.style,"fontTypeMainSub",null),y=d(this.style,"fontSizeAutoTransSub",null),b=d(this.style,"fontTypeAutoTransSub",null);this.colorMainSub=p?`color: ${M[p].color}`:"",this.colorTranSub=b?`color: ${M[b].color}`:"",this.styleLearning=`
        lineHeight: 1.2;
          ${m?`font-size: ${m};`:""}
          ${p?`color: ${M[p].color}; background: ${M[p].background};`:""}
        `,this.styleTrans=`
        lineHeight: 1.2;
        ${y?`font-size: ${y};`:""}
        ${b?`color: ${M[b].color}; background: ${M[b].background};`:""}
      `}try{if(l==="youtube.com"&&this.enable){const m=window.location.href.indexOf("://www.youtube.com/embed/")>=0&&window.location.href.indexOf("controls=0&start=0&origin=")>=0;this.enable=!m}}catch{}this.isNextByWord=d(a,"isNextByWord",this.isNextByWord),this.isNotParse=this.idOrClassSub===O,this.enable&&(document.body.addEventListener("mousedown",this.onMousedown),window.addEventListener("keyup",this.onKeyUp),this.setVideo(),this.isNotParse||(document.addEventListener("click",this.bodyClick),document.addEventListener("mouseover",this.mouseOver),document.addEventListener("fullscreenchange",this.fullscreenchange),this.setLangTo(),this.isAutoTrans=d(a,"isAutoTrans",!1),this.domain=l,l&&Re(l,m=>{if(m){const p=m.scriptCustom;this.containerPopup=m.containerPopup,this.containerFullPopup=m.containerFullPopup;const y=m.type||a.type;this.isReplaceSub=y&&y===B.fixedDom,this.isSubTrack=y&&y===B.videoTrack;const b=document.createElement("style");if(b.innerHTML=m.style,document.head.appendChild(b),this.actions(),this.isSubTrack&&this.addCssHiddenSubWithVideoTrack(this.isTrackShadowPage),p){const T=document.createElement("script");T.innerHTML=p,document.head.appendChild(T)}this.checkChangeSub(this.isAutoTrans)}else{const p=a.type;this.isReplaceSub=p&&p===B.fixedDom,this.isSubTrack=p&&p===B.videoTrack,this.isSubTrack&&this.addCssHiddenSubWithVideoTrack(this.isTrackShadowPage),this.checkChangeSub(this.isAutoTrans)}this.handleChangeHref()})),document.querySelector("html#netflix")&&(this.handleClickNewNeflix(),window.addEventListener("changeMovieEjoy",()=>{this.isHandleClickNewNeflix||this.handleClickNewNeflix()}))),this.closePopup=t;const g=document.createElement("style");g.innerHTML=`
      .ejoy-sub-active{
        color: #1296ba !important;
      }
      
      .ejoy-sub-hovered{
        color: #1296ba !important;
      }
      .${q}{
        cursor: pointer;
        ${this.styleLearning}
      }
      .${q}:hover{
        color: #1296ba !important;
      }
      .${L}{
        position: absolute;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999999;
        cursor: move;
      }
      .${L} > span{
        color: #3CF9ED;
        font-size: 18px;
        text-align: center;
        padding: 0 16px;
        line-height: 1.5;
        background: rgba(32, 26, 25, 0.8);
        // text-shadow: 0px 1px 4px black;
        padding: 0 8px;
        ${this.styleTrans}
      }
      .ej-full-screen-video{
        position: absolute;
        width: 30px;
        height: 30px;
        top: 30px;
        right: 10px;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 99999999;
        cursor: pointer;
      }
      .${C}{
        position: absolute;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 99999999;
        cursor: move;
        padding: 0 8px;
      }
      .${C} > span{
        color: white;
        font-size: 20px;
        line-height: 1.5;
        text-align: center;
        background: rgba(32, 26, 25, 0.8);
        padding: 2px 8px;
        ${this.styleLearning}
      }

      .${C} .${q}{
        background: transparent !important
      }

      .tran-subtitle > span{
        cursor: pointer;
        padding-left: 10px;
        top: 2px;
        position: relative;
      }

      .tran-subtitle > span > span{
        position: absolute;
        top: -170%;
        background: rgba(0,0,0,0.5);
        font-size: 13px;
        line-height: 20px;
        padding: 2px 8px;
        color: white;
        display: none;
        border-radius: 4px;
        white-space: nowrap;
        left: -50%;
        font-weight: normal;
      }

      .viewPopupPro {
        z-index: 2147483647;
        cursor: auto;
        position: absolute;
        z-index: 2147483647;
        background: #111111;
        transition: opacity 1s;
        width: 172px;
        height: 66px;
        opacity: 1;
        border-radius: 6px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }

      .titlePopupPro {
        font-style: normal;
        font-weight: 400;
        font-size: 10px;
        line-height: 12px;
        color: #E5E5E5;
        text-shadow: 0px 3px 3px rgba(0, 0, 0, 0.25);
      }
  
      .viewGoPro {
        background: #FFCC00;
        border-radius: 72.6257px;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 8px;
        padding-left: 10px;
        cursor: pointer;
  
      }

      .viewGoPro svg {
        pointer-events: none;
      }
      
      .textGoPro {
        font-style: normal;
        font-weight: 600;
        font-size: 10px;
        line-height: 12px;
        pointer-events: none;
        text-align: center;
        color: #FFFFFF;
        padding: 4px 14px 4px 4px;
      }

      .viewPopupPro{
        top: auto !important;
        bottom: 15px !important;
      }

      .view-icon-copy-main-sub:hover > span,
      .view-icon-edit-sub:hover > span,
      .view-icon-exit-full-sub:hover > span,
      .view-icon-full-sub:hover > span,
      .iconCrownGoPro:hover > span,
      .view-icon-copy-tran-sub:hover > span {
        display: block;
      }

      .iconCrownGoPro{
        padding-left: 0px !important;
        padding-right: 8px !important;
      }
      .iconCrownGoPro svg{
        width: 17px;
        height: 17px;
      }
      .view-icon-full-sub, .view-icon-exit-full-sub {
        display: flex;
      }

      .view-icon-full-sub > svg, .view-icon-exit-full-sub > svg {
        pointer-events: none;
      }

      .tran-subtitle > span > svg{
        width: 16px;
        height: 16px;
        pointer-events: none;
        display: inline-flex !important;
        vertical-align: baseline !important;
      }
      
      .view-icon-copy-main-sub > svg{
        pointer-events: none;
        ${this.colorMainSub}
      }

      .iconCrownGoPro{
        padding-left: 0 !important;
        padding-right: 8px !important;
      }
      .view-icon-copy-tran-sub > svg{
        pointer-events: none;
        ${this.colorTranSub}
      }

      `,document.head.appendChild(g)})}renderShowAutoTranslate(e,t,s,o,i=30,n=!1){if(!s||!o)return;const a=s.getBoundingClientRect(),l=o.getBoundingClientRect();ke(e,"auto",t,c=>{if(s&&o){this.subTranCache=c.text;let u=document.querySelector("."+L);if(u||(window.isMove=!1,I(u),u=document.createElement("div"),u.className=L),u.innerHTML=`<span class="tran-subtitle">
          ${this.isShowCrownBlur?`<span class="iconCrownGoPro">
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M14 28C21.732 28 28 21.732 28 14C28 6.26801 21.732 0 14 0C6.26801 0 0 6.26801 0 14C0 21.732 6.26801 28 14 28Z" fill="#111111" fill-opacity="0.4"/>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.125 19.8333H8.45548L7 10.4461L9.91381 11.8762L14.2831 7.58325L18.6681 11.8762L21.5833 10.4461L20.125 19.8333Z" fill="#E5E5E5"/>
            </svg>
            <span class="viewPopupPro">
              <span class="titlePopupPro">${H("Turn_on_Dual_Subtitles")}</span>
              <div class="viewGoPro">
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="8" viewBox="0 0 10 8" fill="none">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M8.57143 8H0.950515L0 1.86963L1.9029 2.80353L4.75631 0L7.61998 2.80353L9.52381 1.86963L8.57143 8Z" fill="white" />
                </svg>
                <span class="textGoPro">
                  ${H("Buy_Pro_AI_Dictionary")}
                </span>
              </div>
            </span>
          </span>`:""}
          <span class="view-icon-copy-tran-sub">
            <span>Copy trans subtitle (Alt + B)</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-copy"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
          </span>
          <span class="text-trans-ejoy" style="${this.isShowCrownBlur?"filter: blur(0.25em)":""}" >
            ${this.isShowCrownBlur?_e(c.text):c.text}
          </span>
          <span class="view-icon-edit-sub">
            <span>Edit subtitle</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M11 4H4C3.46957 4 2.96086 4.21071 2.58579 4.58579C2.21071 4.96086 2 5.46957 2 6V20C2 20.5304 2.21071 21.0391 2.58579 21.4142C2.96086 21.7893 3.46957 22 4 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V13" stroke="#E5E5E5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M18.5 2.49998C18.8978 2.10216 19.4374 1.87866 20 1.87866C20.5626 1.87866 21.1022 2.10216 21.5 2.49998C21.8978 2.89781 22.1213 3.43737 22.1213 3.99998C22.1213 4.56259 21.8978 5.10216 21.5 5.49998L12 15L8 16L9 12L18.5 2.49998Z" stroke="#E5E5E5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </span>
          <span class="view-icon-copy-main-sub">
            <span>Copy main subtitle (Alt + C)</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-copy"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
          </span>
        </span>`,!window.isMove){if(window.isMove=!0,n)u.style.bottom=`${(this.offsetY||0)+i}px`;else{const v=(this.offsetY||0)+a.top-a.height-l.top-i;u.style.top=`${v}px`}u.style.left="0",z(u)}o.appendChild(u)}})}hideOriginSub(e){try{e&&e.style&&(e.style.transform="translateX(10000px)")}catch{}}renderMainSub(e,t,s,o=10,i=!1){if(t&&s){let n=document.querySelector("."+C);if(n||(window.isMainMove=!1,I(n),n=document.createElement("div"),n.className=C),n.innerHTML=`<span>${e}</span>`,!window.isMainMove){window.isMainMove=!0;const a=t.getBoundingClientRect();i?n.style.bottom=`${(this.offsetY||0)+o}px`:n.style.top=`${(this.offsetY||0)+a.top-s.getBoundingClientRect().top-o}px`,n.style.left="0",z(n)}s.appendChild(n),this.hoverByIndex(0,!1,!0)}}renderIconFullScreen(e){const t=f.get("showFullSubCustom1")||{},s=this.domain?t[V(this.domain,"\\.","_")]:"";if(e&&s){let o=document.querySelector(".ej-full-screen-video");o||(I(o),o=document.createElement("div"),o.className="ej-full-screen-video"),o.innerHTML=document.fullscreenElement?`
          <span class="view-icon-exit-full-sub">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minimize"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/></svg>
          </span>`:`
        <span class="view-icon-full-sub">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-maximize"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg>
        </span>`,e.appendChild(o)}}setOptions(e){const t=d(e,"quickLookup.enable",!1);this.idOrClassSub=d(e,"quickLookup.elemClass",""),this.posEnable=d(e,"quickLookup.posEnable",!1),this.fixedPos=d(e,"quickLookup.pos",""),this.isNextByWord=d(e,"quickLookup.isNextByWord",this.isNextByWord),t?this.enable||window.addEventListener("keyup",this.onKeyUp):window.removeEventListener("keyup",this.onKeyUp),this.enable=t}goToSettingSub(){R.analytics.sendEvent(["setting_sub"]),chrome.runtime.sendMessage(E(P.openOption,{screen:`?screen=subtitleLookup&domain=${this.domain}`}))}goPopupProBlur(){R.analytics.sendEvent(["ext_pro_ai_dual",this.domain]),chrome.runtime.sendMessage(E(P.go_pro,{moment:"dict",medium:"dual"}))}_closePopup(){this.play(),this.video&&this.video.focus(),this.closePopup&&this.closePopup()}renderItemSub(e,t){return e.tag==="word"?`<span class="${q}" data-text="${e.value}" data-hover="true" data-index="${t}" >${e.value}</span>`:e.value}async replaceSub(e,t,s,o){const i=s?e:[e];let n=0;for(let a=0;a<i.length;a++){const l=i[a];if(l.querySelector('[data-hover="true"]')&&!o)return;const v=l.querySelector("[style]")?l.innerText:l.innerHTML,w=ce(l.innerText);l.innerHTML=w;const h=l.innerText,g=(h||"").trim();this.subHtml[a]=this.subContentCache[a]===g?this.subHtml[a]:v;const m=this.subHtml[a];if(this.subContentCache[a]=g,t)A[h]=A[h]?A[h]:this.mapStrToArr(h),this.subsTokenize=A[h];else{try{_[h]=_[h]?_[h]:de(h,!0).subsTokenize}catch{_[h]=null}this.subsTokenize=_[h]}const p=this.subsTokenize;let y="",b=m;if(!p)return;p.forEach(T=>{const{beforeText:te,text:Ze,restText:oe}=ue(b,T.value);b=oe,y=`${y}${te}${this.renderItemSub(T,n)}`,T.tag==="word"&&n++}),l.innerHTML=y}}getClassSubElement(){if(this.idOrClassSub.indexOf("#shadowRoot#")>=0){const t=this.splitByShadowRoot(this.idOrClassSub);return this._getClassSubShadowRootElement(t)}const e=this.idOrClassSub.split("###");for(let t=0;t<e.length;t++){const s=e[t],o=this._getClassSubElement(s);if(o&&(o.length===void 0||o.length!==void 0&&o.length>0))return o}return null}_getClassSubShadowRootVideo(e=[],t=!1){try{let s=t?e:e.slice(0,e.length-1);const o=s.length;if(o<1)return null;let i=document.querySelector(s[0]);if(o>1)for(let n=1;n<o;n++)i&&(i=i.shadowRoot.querySelector(s[n]));if(i){const n=i.shadowRoot.querySelector(this.idOrClassVideo),a=i.shadowRoot;if(a&&!a.querySelector("#styleHiddenSubEj")){const l=document.createElement("style");l.id="styleHiddenSubEj";const c="video::cue { font-size: 0px !important} }";l.innerHTML=`${c}`,a.appendChild(l)}return n}}catch{}return null}_getClassSubShadowRootElement(e=[]){try{const t=e.length;if(t<=1)return null;let s=document.querySelector(e[0]).shadowRoot.querySelector(e[1]);if(t>2)for(let o=2;o<t;o++)s&&(s=s.shadowRoot.querySelector(e[o]));return s}catch{}return null}_getClassSubElement(e=""){if(document.getElementById(e))return document.getElementById(e);try{if(document.querySelector(`.${e}`))return document.querySelector(`.${e}`)}catch{}return document.querySelectorAll(e)}getClassSubWithCustomTextElement(){return document.querySelector("."+C)?document.querySelector("."+C):this.getClassSubElement()}tranFullSub(){if(!(this.idOrClassSub===O)){const t=this.getClassSubWithCustomTextElement();if(!t)return;const s=t.length!==void 0&&t.length>0,o=((s?this.getParentElement(t):t).innerText||"").trim();this.tranfull(o,s?t[0]:t),this.pause()}}getParentElement(e){return e[0].parentElement}getUtilHasDom(e,t,s,o){const i=e[t];if(!i)return null;if(i.parentElement.style.display==="none"){const n=t+(s?1:-1),a=n<0?o-1:n>=o?0:n;return this.getUtilHasDom(e,a,s,o)}return this.indexHover=t,i}async hoverByIndex(e=0,t=!1,s=!1){if(this.hiddenMainSub)return;this.onMouseLeave(),this.ignorePro&&this.pause(),this.textSelected=[];let o=this.getClassSubWithCustomTextElement();const i=o.length!==void 0&&o.length>0;if(!o||o.length!==void 0&&o.length<=0)return;const n=this.idOrClassSub===O,a=n&&document.querySelector(".ejoy-subtitles")?document.querySelector(".ejoy-subtitles").getAttribute("data-lang"):"",l=((i?this.getParentElement(o):o).innerText||"").trim(),c=t?!this.isNextByWord:this.isNextByWord;if(l){!s&&this.pause(),document.querySelector(`.${q}`)||await this.replaceSub(o,c,i,!n&&this.altKeyCache!==t,!n),o=i?this.getParentElement(o):o;try{o.setAttribute("parent-subtitle","true")}catch{}if(o&&!s){const u=o.querySelector(`.${S}`);u&&u.classList.remove(S);const v=o.querySelectorAll('[data-hover="true"]'),w=v.length;(!this.subCache||this.subCache!==l)&&(this.indexHover=this.isNext?0:w-1),e<0?this.indexHover=w-1:e>=w&&(this.indexHover=0);const h=this.indexHover%w,g=this.getUtilHasDom(v,h,this.isNext,w);if(!g)return;g.classList.add(S);const m=g.getAttribute("data-text")||g.innerText,p=this.getLangTo();this.onClickShowPopup(m,l,g,a,p)}this.subCache=l,this.altKeyCache=t}}getLangTo(){return document.querySelector("[data-lang-to]")?document.querySelector("[data-lang-to]").getAttribute("data-lang-to"):""}removeHoveredClass(){try{this.domData&&this.domData.dom.removeClass(S),this.domData=null}catch{}}}const je=j.config.DEFAULT_TRANSLATE_FROM_ADV,Ve=j.config.eJOYPopId,Ie=22;class Fe{constructor(){this.getSelected=()=>(window.getSelection||document.getSelection)().toString(),this.checkIgnore=e=>{try{const t=e.path[0];this.isTranslate=!(t.nodeName==="INPUT"||t.nodeName==="TEXTAREA"||e.which===2||t.className==="icon")}catch{}},this.handleCaptureTextEvent=e=>{const t=document.querySelector("[class-container-popup-full-screen]");try{if(!e||!e.path)return;const s=e.path[0];if((s.nodeName==="INPUT"||s.nodeName==="TEXTAREA"||!this.isTranslate)&&!e.altKey)return;if(this.isClickInside){this.isClickInside=!1;return}this.onClose();const o=this.getSelected()||"";if(!o)return;const i=Be(o.trim().replace(/\s+/g," "));if(!i.trim())return;const n=e.pageX,l={y:(t?e.clientY:e.pageY)+Ie,x:n};this.translate(i,l,t)}catch{}},this.showText=(e,t,s)=>{const o=N()&&document.querySelector("[class-container-popup-full-screen]")?document.querySelector("[class-container-popup-full-screen]").getAttribute("class-container-popup-full-screen"):"";let i=o?document.querySelector(o).querySelector(".ejoy-in-popup-full"):document.querySelector(".ejoy-in-popup");i||(i=document.createElement("div"),i.className=o?"ejoy-in-popup-full":"ejoy-in-popup",(o?document.querySelector(o):document.querySelector("body")).appendChild(i)),i.innerText=e,i.style=`background-color: #2C2C2C;
    border-radius: 4px;
    color: #B2B2B2;
    font-size: 16px;
    padding: 4px 10px;
    position: ${s?"fixed":"absolute"};
    text-align: center;
    z-index: 9999999999;`,i.style.left=`${t.x}px`,i.style.top=`${t.y}px`,i.style.display="block"},this.onClose=()=>{const e=N()&&document.querySelector("[class-container-popup-full-screen]")?document.querySelector("[class-container-popup-full-screen]").getAttribute("class-container-popup-full-screen"):"",t=document.querySelector(e?".ejoy-in-popup-full":".ejoy-in-popup");t&&(t.style.display="none")},this.isClickInside=!1,this.contextStr="",this.webUrl="",this.isVideo=!1,this.options=null,this.showContentByText=null,this.showIconSelect=null,this.isTranslate=!1}prepare(e){this.lang=e,document.addEventListener("mouseup",t=>{(t.target.id==="eJOY__extension_root"||t.target.id===Ve)&&this.handleCaptureTextEvent(t)}),document.addEventListener("mousedown",t=>{this.checkIgnore(t)}),chrome.storage.onChanged.addListener((t,s)=>{t.lang&&this.setLang(t.lang.newValue)})}setLang(e){this.lang=e}translate(e,t,s){const o=d(this.lang,"translateFrom.code",je.code);let i=d(this.lang,"translateTo.code","vi");if(s){const n=document.querySelector(".ejoy-subtitles");n&&(i=n.getAttribute("data-lang-to"))}chrome.runtime.sendMessage(E(P.trans_simpl,{text:e,context:"",from:o,noCheckAdd:!0,to:i}),n=>{n.error||this.showText(n.text,t,s)})}}function Ne(){const r=f.get("domeMailContent")||"div.adn",e=f.get("domeMailContentDetail")||[".gs > div:last-child .gt .aiL > div",".gs > div:last-child .gt .aiL"];if(document.querySelector(r)){const t=$.last(document.querySelectorAll(r));let s="";if(t)for(let o=0;o<e.length;o++){const i=e[o];if(s=t.querySelector(i)?t.querySelector(i).innerText:"",s)break}chrome.storage.local.set({sendTextToGmailForm:{}}),chrome.runtime.sendMessage(E(P.adv_rewrite,{text:s,type:"Reply",source:"gmail",originSource:encodeURIComponent(location.href)}))}}async function Ye(){const r="open-init-quick-repy-ejoy-ext";if(!document.querySelector(`.${r}`)){await ge('table[role="group"] tbody tr > td:last-child');const e=document.createElement("span");e.innerHTML=`<div><div style="
      font-style: normal;
      line-height: 16px;
      justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, Helvetica, Arial, sans-serif,;
      display: inline-flex;
      flex-direction: row;
      align-items: center;
      padding: 0px 6px;
      gap: 4px;
      color: rgb(33, 43, 54);
      font-size: 13px;
      background: rgb(255, 255, 255);
      border: 1px solid #1DA1F2;
      border-radius: 6px;
      box-shadow: #1DA1F2 0px 2px 0px;
      cursor: pointer;
      height: 28px;
      font-weight: 500;
      transition: background-color 0.2s ease 0s, top 0.1s ease 0s, box-shadow 0.1s ease 0s;
      top: -1px;
      position: relative;
      user-select: none;
      white-space: nowrap;
      margin-left: 16px;
      --darkreader-inline-bgimage: initial;
      --darkreader-inline-color: #dfd7cc;
      --darkreader-inline-bgcolor: #262727;
      --darkreader-inline-border-top: #1DA1F2;
      --darkreader-inline-border-right: #1DA1F2;
      --darkreader-inline-border-bottom: #1DA1F2;
      --darkreader-inline-border-left: #1DA1F2;
      --darkreader-inline-boxshadow: #1DA1F2 0px 2px 0px;
    ">
      <svg style="padding-right: 2px" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M9.8336 19.1666C13.512 19.0678 15.584 16.318 15.4597 13.1578C14.9439 8.51909 9.43752 7.02587 11.6416 0.833252C7.21371 4.64929 4.03479 9.53475 4.17018 13.0107C4.2306 16.3824 6.18158 19.1666 9.8336 19.1666ZM13.1885 14.4621C13.7551 14.4621 14.1628 14.0002 14.2144 13.4363C14.3494 13.0388 14.2144 11.2173 12.8679 10.0495C13.0864 11.5663 12.0406 12.8264 12.1626 13.4363C12.1626 14.0028 12.6219 14.4621 13.1885 14.4621Z" fill="#1DA1F2"/>
      </svg>
      ${H("Quick_reply")}
    </div></div>`,e.className=r,e.style=`
      
    `,e.addEventListener("click",Ne);const t=document.querySelector('table[role="group"] tbody tr > td:last-child');t&&t.parentNode.insertBefore(e,t)}}function ze(r){const e=$.get(r,"originSource",""),t=$.get(r,"text","");if(e===location.href&&t){const s=document.querySelector(f.get("domInsertMail")||"div.editable");s&&(s.innerHTML=t)}}const We=$.throttle(ze,500,{trailing:!1});function Ue(){window.location.pathname&&window.location.host==="mail.google.com"&&(chrome.storage.onChanged.addListener(e=>{e.sendTextToGmailForm&&We(e.sendTextToGmailForm.newValue)}),new MutationObserver(()=>{document.querySelector('table[role="group"] tbody tr > td:last-child')&&Ye()}).observe(document.body,{childList:!0,subtree:!0}))}const Ke=Ee;class Z extends ae.Component{render(){return J.jsx(se,{params:this.props})}}let U=null;const Q=Pe,ee=Me;function K(){R.analytics.sendEvent(["ext_default_settings"]),chrome.runtime.sendMessage(E(P.windowOpen,{url:`chrome-extension://${chrome.runtime.id}/src/pages/options/index.html?screen=onboarding`}),()=>{})}function Ge(){if(window.location.pathname&&window.location.host==="ejoy-english.com"&&window.location.pathname.indexOf("extension/feature")>=0){const r=document.querySelector(".open-default");if(r)r.style.display="block",r.style.cursor="pointer",r.onclick=K;else if(!document.querySelector(".open-init-setting-ejoy-ext")){const e=document.createElement("div");e.innerText=H("Initial_settings"),e.className="open-init-setting-ejoy-ext",e.style=`
        background: #1DA1F2;
        border-radius: 40px;
        font-size: 16px;
        line-height: 24px;
        margin: 0 0 30px 0;
        color: #FFFFFF;
        white-space: nowrap;
        padding: 4px 25px;
        position: absolute;
        bottom: -30px;
        left: 50%;
        transform: translateX(-50px);
        cursor: pointer;
        `,e.addEventListener("click",K);const t=document.querySelector("section.header");t&&(t.style.paddingBottom="40px",t.appendChild(e))}}}const G=(r,e="authorize")=>()=>{r&&chrome.storage.local.set({redirectUriAfterLogin:r}),e!=="authorize"&&R.analytics.sendEvent(["ext_signup","login welcome"]),me(e,t=>{`${t}${chrome.runtime.id}`,fe()})};function Je(){try{if(window.location.pathname&&window.location.host==="ejoy-english.com"&&window.location.pathname.indexOf("extension/welcome")>=0){const r=document.querySelector(".cta-btn > a"),e=document.querySelector(".cta-btn > p > a");if(r){const t=r.getAttribute("href");if(t){const o=new URL(t).searchParams.get("redirect_uri");r.setAttribute("href","#"),r.addEventListener("click",G(o,"signup"))}}if(e){const t=r.getAttribute("href");if(t){const o=new URL(t).searchParams.get("redirect_uri");e.setAttribute("href","#"),e.addEventListener("click",G(o))}}}}catch{}}function Xe(){try{if(window.location.pathname&&window.location.host==="ejoy-english.com"&&window.location.pathname.indexOf("/pdf")>=0)try{document.querySelector('[class^="uploadDocument_icon"]')&&(document.querySelector('[class^="uploadDocument_icon"]').style.pointerEvents="none"),document.querySelector('[class^="uploadDocument_ejoyPro"]')&&document.querySelector('[class^="uploadDocument_ejoyPro"]').addEventListener("click",()=>{R.analytics.sendEvent(["ext_pro_pdf"])})}catch{}}catch{}}he(document).ready(()=>{Ge(),Je(),Ue(),He(),Xe();let r=0,e=null;ye().then(t=>{t.video&&(U=new $e,U.prepare(Q,ee)),Y("lang",o=>{const i=o.lang||{};new Fe().prepare(i)});function s(o){const i=o.attachShadow({mode:"open"});i.innerHTML=`
        <style>
          @import url('https://fonts.googleapis.com/css?family=Open+Sans:300,400,600');
          ${ie}
          ${ne}
        </style>
        <div id='eJOY__extension_shadow' />
        `,le.render(J.jsx(Z,{}),i.querySelector("#eJOY__extension_shadow")),re(i)}e&&clearInterval(e),e=setInterval(()=>{if(r++,r>4&&(r=0,clearInterval(e)),document.getElementById("eJOY__extension_root"))return;const o=document.createElement("div");o.id="eJOY__extension_root",o.className="eJOY__extension_root_class",o.style="all: unset;",document.documentElement.appendChild(o),s(o)},1e3),chrome.runtime.sendMessage(E(P.browser_action,{url:window.location.href}),o=>{})})});const yt=Object.freeze(Object.defineProperty({__proto__:null,closePop:ee,default:Z,eJOYPopId:Ke,showPop:Q},Symbol.toStringTag,{value:"Module"}));export{ft as a,yt as i,mt as p,gt as s};
