import{_ as s}from"./_defineProperty.BZf4elU2.js";var i=s;function t(r,e,a){e=="__proto__"&&i?i(r,e,{configurable:!0,enumerable:!0,value:a,writable:!0}):r[e]=a}var o=t;export{o as _};
