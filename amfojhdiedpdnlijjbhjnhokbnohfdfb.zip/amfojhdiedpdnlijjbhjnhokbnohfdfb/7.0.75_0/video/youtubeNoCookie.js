window.currentUrl = ''

window.setInterval(() => {
  const player = document.querySelector(".video-stream.html5-main-video");
  const subsToggleElement = document.querySelector(".ytp-subtitles-button");
  if (window.location.href != window.currentUrl) {
    if (window.location.href.match(/embed\/[A-z0-9]*/) != null &&
      window.location.href.match(/embed\/[A-z0-9]*/).length > 0) {
      window.dispatchEvent(new CustomEvent("ejoy_get_all_lang_sub", { detail: window.location.href.match(/embed\/[A-z0-9\-]*/)[0].split("/")[1] }));
    }
    window.currentUrl = window.location.href;
  }

  if (player) {
    if (!window.isLoaded) {
      window.isLoaded = true;
      window.dispatchEvent(new CustomEvent("ejoyVideoReady"));
      // if (subsToggleElement && subsToggleElement.getAttribute("aria-pressed") === "true") {
      //   // player && player.toggleSubtitles && player.toggleSubtitles();
      //   // player && player.toggleSubtitles && player.toggleSubtitles();
      //   window.dispatchEvent(new CustomEvent("renderCoreLayoutEjoy"));
      // } else {
      // }
      window.dispatchEvent(new CustomEvent("ejoySubtitlesChanged", { detail: "" }));
    }
  } else {
    window.isLoaded = false;
  }

  if (subsToggleElement) {
    if (window.subtitlesEnabled && subsToggleElement.getAttribute("aria-pressed") === "false") {
      window.subtitlesEnabled = false;
      // window.dispatchEvent(new CustomEvent("ejoySubtitlesChanged", { detail: "" }));
    }
  }
}, 500);

(open => {
  XMLHttpRequest.prototype.open = function (method, url) {
    if (url.match(/^http/g) !== null) {
      const urlObject = new URL(url);
      if (urlObject.pathname === "/api/timedtext") {
        window.subtitlesEnabled = true;
        const lang = urlObject.searchParams.get("tlang") || urlObject.searchParams.get("lang")
        window.dispatchEvent(new CustomEvent("ejoy_data", { detail: urlObject.href }));
        window.dispatchEvent(
          new CustomEvent("ejoySubtitlesChanged", { detail: lang })
        );
      }
    }
    open.call(this, method, url);
  };
})(XMLHttpRequest.prototype.open);


